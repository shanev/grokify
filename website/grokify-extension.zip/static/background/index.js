var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,n,o,r,i){var a="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},u="function"==typeof a[r]&&a[r],f=u.cache||{},d="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function p(e,n){if(!f[e]){if(!t[e]){var o="function"==typeof a[r]&&a[r];if(!n&&o)return o(e,!0);if(u)return u(e,!0);if(d&&"string"==typeof e)return d(e);var i=Error("Cannot find module '"+e+"'");throw i.code="MODULE_NOT_FOUND",i}l.resolve=function(n){var o=t[e][1][n];return null!=o?o:n},l.cache={};var s=f[e]=new p.Module(e);t[e][0].call(s.exports,l,s,s.exports,this)}return f[e].exports;function l(e){var t=l.resolve(e);return!1===t?{}:p(t)}}p.isParcelRequire=!0,p.Module=function(e){this.id=e,this.bundle=p,this.exports={}},p.modules=t,p.cache=f,p.parent=u,p.register=function(e,n){t[e]=[function(e,t){t.exports=n},{}]},Object.defineProperty(p,"root",{get:function(){return a[r]}}),a[r]=p;for(var s=0;s<n.length;s++)p(n[s]);if(o){var l=p(o);"object"==typeof exports&&"undefined"!=typeof module?module.exports=l:"function"==typeof e&&e.amd?e(function(){return l}):i&&(this[i]=l)}}({kgW6q:[function(e,t,n){e("../../../background")},{"../../../background":"8VaxY"}],"8VaxY":[function(e,t,n){var o=e("./lib/indicators");chrome.action.setBadgeBackgroundColor({color:"#1a1a1a"}),chrome.runtime.onMessage.addListener((e,t)=>{if("updateBadge"!==e.action)return!1;let n=t.tab?.id;return void 0!==n&&"number"==typeof e.count&&(chrome.action.setBadgeText({tabId:n,text:(0,o.formatBadgeText)(e.count)}),!1)}),chrome.tabs.onUpdated.addListener((e,t)=>{"loading"===t.status&&chrome.action.setBadgeText({tabId:e,text:""})})},{"./lib/indicators":"2sUyO"}],"2sUyO":[function(e,t,n){var o=e("@parcel/transformer-js/src/esmodule-helpers.js");o.defineInteropFlag(n),o.export(n,"ORIGINAL_HREF_ATTR",()=>r),o.export(n,"INDICATOR_STYLE_ID",()=>i),o.export(n,"SHOW_INDICATORS_KEY",()=>a),o.export(n,"INDICATOR_CSS",()=>u),o.export(n,"isWikipediaHost",()=>f),o.export(n,"shouldShowInlineIndicators",()=>d),o.export(n,"describeOriginalHref",()=>p),o.export(n,"buildLinkTitle",()=>s),o.export(n,"formatBadgeText",()=>l);let r="grokify-original",i="grokify-indicator-style",a="showIndicators",u=`
a[data-grokified="true"]:not(:has(img, svg, picture, video))::after {
  content: "G" !important;
  display: inline-block !important;
  position: static !important;
  width: auto !important;
  height: auto !important;
  margin: 0 0 0 0.15em !important;
  padding: 0 0.25em !important;
  border: 0 !important;
  border-radius: 0.3em !important;
  font: 700 0.6em/1.4 system-ui, -apple-system, "Segoe UI", sans-serif !important;
  font-variant: normal !important;
  letter-spacing: normal !important;
  text-transform: none !important;
  text-indent: 0 !important;
  text-shadow: none !important;
  text-decoration: none !important;
  vertical-align: super !important;
  color: #fff !important;
  -webkit-text-fill-color: #fff !important;
  background: #1a1a1a !important;
  opacity: 0.75 !important;
  filter: none !important;
  mask: none !important;
  -webkit-mask: none !important;
  transform: none !important;
  visibility: visible !important;
  pointer-events: none !important;
}
`;function f(e){return"wikipedia.org"===e||e.endsWith(".wikipedia.org")}function d(e,t){return!1!==t&&!f(e)}function p(e){let t=e.replace(/^https?:\/\//,"");try{return decodeURI(t)}catch{return t}}function s(e,t){let n=`Grokify: opens on Grokipedia (was ${p(t)})`;return e?`${e}
${n}`:n}function l(e){return e<=0?"":e>999?"999+":String(e)}},{"@parcel/transformer-js/src/esmodule-helpers.js":"hbR2Q"}],hbR2Q:[function(e,t,n){n.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},n.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},n.exportAll=function(e,t){return Object.keys(e).forEach(function(n){"default"===n||"__esModule"===n||t.hasOwnProperty(n)||Object.defineProperty(t,n,{enumerable:!0,get:function(){return e[n]}})}),t},n.export=function(e,t,n){Object.defineProperty(e,t,{enumerable:!0,get:n})}},{}]},["kgW6q"],"kgW6q","parcelRequireed79"),globalThis.define=t;